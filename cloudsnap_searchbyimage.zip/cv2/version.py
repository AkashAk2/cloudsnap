opencv_version = "4.7.0.72"
contrib = False
headless = True
rolling = False
ci_build = True